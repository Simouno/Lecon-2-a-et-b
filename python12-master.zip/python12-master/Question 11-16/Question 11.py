from Tkinter import *
import Tkinter
Tkinter.title("Message pour tout le monde")
Tkinter.configure(width=500,height=500)
Tkinter.configure(background="yellow")
message=Label(fen, text="Text 1")
message=Label(fen, text="Text 2")
bou=Button(fen,text="Bouton 1", bg="black", fg="yellow")
bou.pack()
bou=Bouton(fen,text="Bouton 2", bg="black", fg="yellow")
bou.pack()
Tkinter.Tk()
