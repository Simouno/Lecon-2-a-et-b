# Python12
Code de Simon Losier pour le cour de programation 12
cliquer sur les question pour avoir acces aux code pour la question.
