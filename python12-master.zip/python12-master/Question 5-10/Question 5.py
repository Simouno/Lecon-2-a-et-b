from tkinter import *
fen=Tk()
fen.title("Window")
fen.configure(width=500,height=200)
fen.configure(background="magenta")

