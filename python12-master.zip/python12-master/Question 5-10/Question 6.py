from tkinter import *
fen=Tk()
fen.title("Question 6")
fen.configure(width=100,height=100)
fen.configure(background="red")
