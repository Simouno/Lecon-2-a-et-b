from Tkinter import *
import Tkinter
Tkinter.title("Window")
Tkinter.configure(width=500,height=200)
Tkinter.configure(background="magenta")
message=Label(fen, text="Salut le monde!")
message=Label(fen, text="J'aime la programmaion!")
Tkinter.Tk()
