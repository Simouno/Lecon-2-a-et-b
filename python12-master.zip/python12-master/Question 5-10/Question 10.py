from Tkinter import *
import Tkinter
Tkinter.title("Message pour tout le monde")
Tkinter.configure(width=50,height=500)
Tkinter.configure(background="yellow")
message=Label(fen, text="Text 1")
message=Label(fen, text="Text 2")
Tkinter.Tk()
