from Tkinter import *
import Tkinter
Tkinter.title("Window")
Tkinter.configure(width=800,height=800)
Tkinter.configure(background="blue")
message=Label(fen, text="Salut le monde!")
message=Label(fen, text="J'aime la programmaion!")
message=label(fen, text="Text 1")
message=label(fen, text="Text 2")
message=label(fen, text="Text 3")
Tkinter.Tk()
